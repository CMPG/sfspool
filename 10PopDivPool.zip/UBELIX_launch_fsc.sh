#!/bin/bash
#SBATCH --mail-user=nina.marchi@unibe.ch
#SBATCH --mail-type=end,fail
#SBATCH --job-name=Estimates
#SBATCH --partition=bdw-invest
#SBATCH --mem-per-cpu=2G
#Need to specify how many node I want : 1 node = 20 runs , 5 nodes = 100 runs
#SBATCH --nodes=1
#Need to specify 20 tasks per node to fill it up completely
#SBATCH --ntasks-per-node=20
#SBATCH --cpus-per-task=1
#SBATCH --output=/dev/null
#SBATCH --error=/dev/null
#SBATCH --time=24:00:00

path=/storage/scratch/iee_cmpg/cmpg/sfsPool/
samples=$3
genericName=10PopDivPool-n${samples}


i=$1 # To be changed in the different launch files
d=$2

for case in pool-Adm pool-noAdm fis-Adm fis-noAdm noStruct-Adm noStruct-noAdm
do
	fileDirName=${path}/Estimates/${genericName}_${i}_def${d}-${case}
	for ((run=1; run<=20; run ++))
	do
		myfile=${fileDirName}/run${run}/${genericName}_${i}_def${d}_${run}.sh
		srun -n 1 -o ${path}/Estimates/conOutput/${genericName}_${i}_def${d}-${case}_${run}.out -e ${path}/Estimates/conOutput/${genericName}_${i}_def${d}-${case}_${run}.err ${myfile} -N1 &
	done
done

wait

echo "Travail terminé"
exit 0