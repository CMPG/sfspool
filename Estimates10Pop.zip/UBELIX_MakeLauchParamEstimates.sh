#!/bin/bash
#SBATCH --mail-user=nina.marchi@unibe.ch
#SBATCH --mail-type=end,fail
#SBATCH --job-name="Make"
#SBATCH --partition=bdw-invest
#SBATCH --mem-per-cpu=2G
#Need to specify how many node I want : 1 node = 20 runs , 5 nodes = 100 runs
#SBATCH --nodes=1
#Need to specify 20 tasks per node to fill it up completely
#SBATCH --ntasks-per-node=20
#SBATCH --cpus-per-task=1
#SBATCH --output=/dev/null
#SBATCH --error=/dev/null
#SBATCH --time=24:00:00


path=/storage/scratch/iee_cmpg/cmpg/sfsPool
msgs=conOutput
fsc=fsc2709 #Has to be in the path folder

#----- Simulated data framework -----
samples=$1
SFSName=10PopDivPool
genericName=${SFSName}-n${samples}
run_bottom=1
run_top=10
def_bottom=$2
def_top=$3

#----- Parameters estimation framework ------
numRuns=20
runBase=1

numSims=500000
totNumLoops=40
numCores=1
numBatches=1
#logprecision=""
logprecision="--logprecision 18"
quiet="-q"
#SFStype="-m" ##minor allele freq
SFStype="-d" ##derived allele freq
#useMonoSites="-0" #Uncomment this line NOT to use monomorphic sites
useMonoSites="" #Uncomment this line to use monomorphic sites
#asm="--ASM"
asm=""
minValidSFSEntry=1


cd ${path}
chmod 777 ${fsc}
mkdir Estimates/${msgs} 2>/dev/null
for (( i=${run_bottom}; i<=${run_top}; i++ ))
do
	for (( d=${def_bottom}; d<=${def_top}; d++ ))
	do
		curDef=${genericName}_def${d}
		obsFile=${genericName}_${i}_def${d}_jointDAFpop1_0.obs
		tplFile=${genericName}_${i}_def${d}.tpl
		estFile=${genericName}_${i}_def${d}.est
		for case in pool-Adm pool-noAdm fis-Adm fis-noAdm noStruct-Adm noStruct-noAdm
		do
			fileDirName=${path}/Estimates/${genericName}_${i}_def${d}-${case}
			mkdir ${fileDirName} 2>/dev/null
			for (( runsDone=${runBase}; runsDone<=${numRuns}; runsDone++ ))
			do
				echo ${i}_${d}_${case}_${runsDone}
				mkdir ${fileDirName}/run${runsDone} 2>/dev/null
				cd ${fileDirName}/run${runsDone}
				cp ${path}/Estimates/${genericName}-${case}.tpl ./${tplFile}
				cp ${path}/Estimates/${genericName}-${case}.est ./${estFile}
				cp ${path}/${SFSName}/${SFSName}_${i}/${SFSName}_def${d}_jointDAFpop1_0.obs ./${obsFile}
				
				jobName=${genericName}_${i}_def${d}_${runsDone}.sh
				#Creating bash file on the fly
				(
				echo "#!/bin/bash"
				echo "#Slurm options"
				echo "#SBATCH --workdir=`pwd`"
				echo "#SBATCH --mail-user=nina.marchi@unibe.ch"
				echo ""
				echo "# specify resources needed"
				echo "#SBATCH --time=192:00:00"
				echo ""
				echo "#SBATCH --output=\"${path}/Estimates/${msgs}/${genericName}_${i}_def${d}_${case}_$runsDone.out\""
				echo "#SBATCH --error=\"${path}/Estimates/${msgs}/${genericName}_${i}_def${d}_${case}_$runsDone.err\""
				echo "#SBATCH --mail-type=none"
				echo "#SBATCH --partition=bdw-invest"
				echo "#SBATCH --cpus-per-task=${numCores}"
				echo ""
				echo "export OMP_NUM_THREADS=${numCores}"
				echo ""
				echo "#chmod +x ${path}/${fsc}"
				echo "cd ${fileDirName}/run${runsDone}" 
				echo ""
				echo "echo \"Analysis of file ${genericName} in case ${case} for def ${d} (replicate ${i})\""
				echo "#Computing likelihood of the parameters using the CM-Brent algorithm"
				echo "echo \"\""
				echo "${path}/${fsc} -t ${tplFile} -e ${estFile} -n${numSims} -M -c${numCores} -B${numBatches} ${SFStype} -L${totNumLoops} ${quiet} ${logprecision} -C${minValidSFSEntry} ${useMonoSites}"                          
				echo ""
				echo "#Zipping output files"			
				echo "tar -zcvf ${fileDirName}/run${runsDone}.tar.gz ${fileDirName}/run${runsDone} -P"
				#Removing simulated directory
				echo "rm -r ${fileDirName}/run${runsDone}"
				echo "echo \"\""
				echo "echo \"Job $runsDone terminated\""
				) > ${jobName}
				
				chmod +x ${jobName}
				echo "Bash file $jobName created"
			done
		done
	done
done

